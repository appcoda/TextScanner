//
//  ScanAndRecognizeTextApp.swift
//  ScanAndRecognizeText
//
//  Created by Gabriel Theodoropoulos.
//

import SwiftUI

@main
struct ScanAndRecognizeTextApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
